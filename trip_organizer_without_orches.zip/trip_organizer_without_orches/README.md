# GenAIprojects
These projects are industry ready projects 

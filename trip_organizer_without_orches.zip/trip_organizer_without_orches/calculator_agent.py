class Calculator:
    def __init__(self,model,google_search):
        self.model = model
        self.calculated = False
        self.calculations_so_far = []
        self.google_search = google_search

    def calculation_validator(self,travel_info):
        prompt_calculation_validation = f"""strictly return True if complete calculation if calculation is still pending
        then return False travel_info:{travel_info},calculations_so_far:{self.calculations_so_far}"""
        return self.model.generate_content(prompt_calculation_validation).text

    def get_price(self,travel_info):
        prompt_for_price_search = f"""qenerate well defined to make google search travel_info:{travel_info},calculations_so_far:{self.calculations_so_far}"""
        query_for_online_search = self.model.generate_content(prompt_for_price_search).text
        searched_result = self.google_search.search(query_for_online_search)
        print(searched_result)
        return searched_result

    def calculate(self,travel_info):
        for i in range(1):
            searched_for_price = self.get_price(travel_info)
            self.calculations_so_far.append(searched_for_price)
            self.calculated = self.calculation_validator(travel_info)
        return self.final_calculation(travel_info)

    def final_calculation(self,travel_info):
        prompt_to_calculate_value = f"""{travel_info,self.calculations_so_far}"""
        return self.model.generate_content(prompt_to_calculate_value)



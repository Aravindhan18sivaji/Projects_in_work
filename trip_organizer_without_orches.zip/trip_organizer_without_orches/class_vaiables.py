serper_key = "1690123d32e0893fc3fa1528142683b109c9bfe5" # serper api
request_type = 'application/json'


from google_search import GoogleSearch
from class_vaiables import serper_key,request_type
import requests
from bs4 import BeautifulSoup
import google.generativeai as genai
genai.configure(api_key="AIzaSyDUcDLaA3f_ZziysIjGxWUSVaoJB2J7fZM")


class WebSearching:
    def __init__(self):
        self.google_search = GoogleSearch(serper_key,request_type)
        self.model = genai.GenerativeModel("gemini-1.5-flash")

    @staticmethod
    def web_reader(url):
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")

        # Get all cleaned text from the webpage
        full_content = soup.get_text(separator="\n", strip=True)
        print(full_content)

    def online_search(self):
        self.web_searched_results = self.google_search.search("tcp protocol website links")
        # print(self.web_searched_results)
        self.linker_picker()

    def linker_picker(self):
        prompt_for_picking_links = f"""
                                     from the given context, get only the links from given context
                                       
                                     context : {self.web_searched_results}    
                  
                                    expected_output from your side nothing other than comma separated links:
                                    "https://www.geeksforgeeks.org/computer-networks/what-is-transmission-control-protocol-tcp/,https://en.wikipedia.org/wiki/User_Datagram_Protocol"
                                    """
        links_picked_by_llm = self.model.generate_content(prompt_for_picking_links).text
        links_picked_by_llm_list = links_picked_by_llm.split(',')
        self.web_reader(links_picked_by_llm_list[1])
        # print(links_picked_by_llm_list)


web_searching = WebSearching()
web_searching.online_search()
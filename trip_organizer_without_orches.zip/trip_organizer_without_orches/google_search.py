import http.client
import json


class GoogleSearch:
    def __init__(self,serper_key="",request_type=""):

        self.conn = http.client.HTTPSConnection("google.serper.dev")
        self.headers = {
            'X-API-KEY': serper_key,
            'Content-Type': request_type
        }

    def search(self,query):
        payload = json.dumps({
            "q": query
        })

        self.conn.request("POST", "/search", payload, self.headers)
        res = self.conn.getresponse()
        data = res.read()
        return data.decode("utf-8")


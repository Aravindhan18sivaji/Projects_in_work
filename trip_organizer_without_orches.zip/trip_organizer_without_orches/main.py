from google_search import GoogleSearch
from class_vaiables import serper_key,request_type
import google.generativeai as genai
from query_generator import QueryGenerator
from search_validator import SearchValidation
from calculator_agent import Calculator
from schedular_agent import SchedularAgent
genai.configure(api_key="AIzaSyDUcDLaA3f_ZziysIjGxWUSVaoJB2J7fZM")


class TripOrganizer:
    def __init__(self):
        # attributes
        self.model = genai.GenerativeModel("gemini-1.5-flash")
        self.travel_info_collection = []
        self.structured_content_from_online_search = ""
        self.calculated_summary = ""

        # initialising the classes
        self.query_generator = QueryGenerator(self.model)
        self.googlesearch = GoogleSearch(serper_key=serper_key,request_type=request_type)

        self.search_validator = SearchValidation(self.model)
        self.calculator_agent = Calculator(self.model,self.googlesearch)
        self.schedular_agent = SchedularAgent(self.model)

    def get_location(self,location):
        searched_result = self.search_validator.search_validation(location)
        # print("searched_result:",searched_result)
        # prompt_for_content_structuring = f"""structure the google searches {searched_result}"""
        # self.structured_content_from_online_search = self.model.generate_content(prompt_for_content_structuring)
        # self.calculated_summary = self.calculator_agent.calculate(self.structured_content_from_online_search)
        # final_system_output = self.schedular_agent.schedular(self.calculated_summary)

        # print(final_system_output)


trip_organizer = TripOrganizer()
trip_organizer.get_location("thailand")

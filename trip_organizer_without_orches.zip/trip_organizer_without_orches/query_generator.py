class QueryGenerator:
    def __init__(self,model):
        self.model = model

    def query_generation(self,search_requirement,search_history):
        prompt_for_query_generation = f"generate well defined query to google search, for the {search_requirement,search_history}"
        return self.model.generate_content(prompt_for_query_generation).text


# import numpy as np
#
# values = [1, 2, 3, 4, 5]
# probabilities = [1/9, 2/9, 3/9, 2/9, 1/9]  # sum must be 1
#
# for i in range(9):
#     nums = np.random.choice(values , p=probabilities)
#
#     print(nums)
#
# import http.client
# import json
#
# conn = http.client.HTTPSConnection("google.serper.dev")
# payload = json.dumps({
#   "q": "who is trump"
# })
# headers = {
#   'X-API-KEY': '1690123d32e0893fc3fa1528142683b109c9bfe5',
#   'Content-Type': 'application/json'
# }
# conn.request("POST", "/search", payload, headers)
# res = conn.getresponse()
# data = res.read()
# print(data.decode("utf-8"))



# Configure Gemini API


# Initialize the Gemini 1.5 Flash model


  # Should be "True" or "False"


w = 'ab'
n = list(w)
print(n)

class SchedularAgent:
    def __init__(self,model):
        self.model = model

    def schedular(self,calculated_summary):
        prompt = f"""make a schedule for given trip details summarize and tabulate {calculated_summary}"""
        return self.model.generate_content(prompt).text


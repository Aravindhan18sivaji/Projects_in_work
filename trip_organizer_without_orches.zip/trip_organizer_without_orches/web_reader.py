# import requests
# from bs4 import BeautifulSoup
#
#
# def read_url(url: str) -> str:
#     try:
#         # Fetch the page
#         response = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
#         response.raise_for_status()
#
#         # Parse HTML
#         soup = BeautifulSoup(response.text, "html.parser")
#
#         # Extract only text (remove scripts, styles, etc.)
#         for script in soup(["script", "style"]):
#             script.extract()
#
#         text = soup.get_text(separator=" ", strip=True)
#         return text[:2000]  # Limit to first 2000 chars for LLM
#     except Exception as e:
#         return f"Error reading URL: {e}"
#
#
# # Example usage
# print(read_url("https://www.bbc.com/news"))
#

#
#
# import requests
# from bs4 import BeautifulSoup
#
# def read_full_webpage(url: str, max_chars: int = None) -> str:
#     """
#     Fetches and extracts the full visible text content of a webpage.
#     Returns the complete text, optionally truncated to max_chars.
#     """
#     try:
#         # Send HTTP request to fetch full HTML
#         response = requests.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
#         response.raise_for_status()
#         html_content = response.text
#
#         # Parse and clean the HTML
#         soup = BeautifulSoup(html_content, "html.parser")
#         for tag in soup(["script", "style", "header", "footer", "nav", "aside"]):
#             tag.decompose()
#
#         # Extract all visible text
#         text = soup.get_text(separator="\n", strip=True)
#
#         return text[:max_chars] if max_chars else text
#
#     except Exception as e:
#         return f"Error fetching or parsing {url}: {e}"
#
# # Example usage
# url = "https://www.geeksforgeeks.org/computer-networks/what-is-transmission-control-protocol-tcp/"
# full_text = read_full_webpage(url)
#
# print(full_text)  # Print first 1000 characters for preview




import requests
from bs4 import BeautifulSoup

url = "https://www.geeksforgeeks.org/computer-networks/what-is-transmission-control-protocol-tcp/"
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

# Get all cleaned text from the webpage
full_content = soup.get_text(separator="\n", strip=True)
print(full_content)

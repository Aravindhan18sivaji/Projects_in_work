
from google_search import GoogleSearch
from googleapiclient.discovery import build
from class_vaiables import serper_key ,request_type
import requests
from bs4 import BeautifulSoup
import google.generativeai as genai
genai.configure(api_key="AIzaSyDUcDLaA3f_ZziysIjGxWUSVaoJB2J7fZM")

from urllib.parse import urlparse, parse_qs

def extract_id(youtube_url):
    parsed_url = urlparse(youtube_url)
    query_params = parse_qs(parsed_url.query)

    if "v" in query_params:   # 🎥 Single video
        return query_params["v"][0]
    elif "list" in query_params:   # 📂 Playlist
        # Your API Key (get from Google Cloud Console)
        api_key = "AIzaSyC2PcEfTlBCQRnNBQqFUHz0gAtMBZRY5A0"

        # Playlist ID
        playlist_id = query_params['list'][0]

        # Build YouTube API client
        youtube = build("youtube", "v3", developerKey=api_key)

        video_ids = []

        next_page_token = None
        while True:
            request = youtube.playlistItems().list(
                part="contentDetails",
                playlistId=playlist_id,
                maxResults=50,  # max allowed per request
                pageToken=next_page_token
            )
            response = request.execute()

            # Extract video IDs
            for item in response["items"]:
                video_ids.append(item["contentDetails"]["videoId"])

            next_page_token = response.get("nextPageToken")

            if not next_page_token:
                break

        print("Video IDs:", video_ids)
        return video_ids
    else:
        return {"type": "unknown", "id": None}


class WebSearching:
    def __init__(self):
        self.google_search = GoogleSearch(serper_key ,request_type)
        self.model = genai.GenerativeModel("gemini-1.5-flash")

    # @staticmethod
    # def transcript_reader(video_link):

    def online_search(self):
        self.web_searched_results = self.google_search.search("thailand vlog youtube video links")
        # print(self.web_searched_results)
        return self.linker_picker()

    def linker_picker(self):
        prompt_for_picking_links = f"""
                                     from the given context, get only the links from given context

                                     context : {self.web_searched_results}

                                    expected_output from your side nothing other than comma separated links:
                                    "https://www.geeksforgeeks.org/computer-networks/what-is-transmission-control-protocol-tcp/,https://en.wikipedia.org/wiki/User_Datagram_Protocol"
                                    """
        links_picked_by_llm = self.model.generate_content(prompt_for_picking_links).text
        links_picked_by_llm_list = links_picked_by_llm.split(',')
        print(links_picked_by_llm_list)
        return links_picked_by_llm_list[0]
        # print(links_picked_by_llm_list)


web_searching = WebSearching()
links = web_searching.online_search()

from youtube_transcript_api import YouTubeTranscriptApi


def get_youtube_transcript(video_id):
    try:
        # Based on the available methods, try using 'fetch'
        api_instance = YouTubeTranscriptApi()
        transcript = api_instance.fetch(video_id)
        return transcript
    except Exception as e:
        print(f"Error with fetch method: {e}")
        try:
            # Try using 'list' method if fetch doesn't work
            result = api_instance.list(video_id)
            return result
        except Exception as e2:
            print(f"Error with list method: {e2}")
            return None


# Also try the static method approach (more common)
# def get_youtube_transcript_static(video_id):
#     try:
#         # Try static method call
#         transcript = YouTubeTranscriptApi.fetch(video_id)
#         return transcript
#     except Exception as e:
#         print(f"Error with static fetch: {e}")
#         try:
#             transcript = YouTubeTranscriptApi.list(video_id)
#             return transcript
#         except Exception as e2:
#             print(f"Error with static list: {e2}")
#             return None

# # Test with Rick Roll video ID
# video_id = "dQw4w9WgXcQ"
print(links)
video_id = extract_id(links)
print("*" * 100,video_id)
if isinstance(video_id, list):
    print("*" * 100,video_id)
    video_id = video_id[0]

print("Trying instance method:")
transcript = get_youtube_transcript(video_id)

# if not transcript:
#     print("\nTrying static method:")
#     transcript = get_youtube_transcript_static(video_id)

if transcript:
    # print(f"\nTranscript type: {type(transcript)}")
    # print(f"Transcript content: {transcript}")

    # # Try to iterate if it's a list/dict
    # if isinstance(transcript, list):
    #     for entry in transcript:
    #         if isinstance(entry, dict) and 'start' in entry and 'text' in entry:
    #             print(f"{entry['start']:.2f}s - {entry['text']}")
    #         else:
    #             print(f"Entry: {entry}")
    # assuming `transcript` is your FetchedTranscript object
    only_text = ",".join(snippet.text for snippet in transcript.snippets)

    print(only_text)

    # if isinstance(transcript, dict):
    #     print("Dictionary result:", transcript)
    # else:
    #     print("Unexpected format:", transcript)
else:
    print("Could not retrieve transcript with either method")

# Let's also check what these methods expect
# print(f"\nFetch method signature: {YouTubeTranscriptApi.fetch.__doc__}")
# print(f"List method signature: {YouTubeTranscriptApi.list.__doc__}")




# Example usage
# print(extract_id("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
# print(extract_id("https://www.youtube.com/playlist?list=PLUDuSYCnVh-Ty4IFqm194Q7mhY7mxDQXO"))
#

#jo